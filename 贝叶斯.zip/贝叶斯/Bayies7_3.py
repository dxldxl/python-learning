# -*- coding: utf-8 -*-
"""
Created on Tue Aug  3 15:13:20 2021

@author: cui
"""

import numpy as np
import matplotlib.pyplot as plt
from pylab import *
import operator

#特征字典
featureDic={
    '色泽': ['浅白', '青绿', '乌黑'],
    '根蒂': ['硬挺', '蜷缩', '稍蜷'],
    '敲声': ['沉闷', '浊响', '清脆'],
    '纹理': ['清晰', '模糊', '稍糊'],
    '脐部': ['凹陷', '平坦', '稍凹'],
    '触感': ['硬滑', '软粘']
    }

def getDateSet():
    """
    get watermelon data set 3.0.
    :return: 编码好的数据集以及特征的字典。
    """
    dataSet=[
        ['青绿', '蜷缩', '浊响', '清晰', '凹陷', '硬滑', 0.697, 0.460, 1],
        ['乌黑', '蜷缩', '沉闷', '清晰', '凹陷', '硬滑', 0.774, 0.376, 1],
        ['乌黑', '蜷缩', '浊响', '清晰', '凹陷', '硬滑', 0.634, 0.264, 1],
        ['青绿', '蜷缩', '沉闷', '清晰', '凹陷', '硬滑', 0.608, 0.318, 1],
        ['浅白', '蜷缩', '浊响', '清晰', '凹陷', '硬滑', 0.556, 0.215, 1],
        ['青绿', '稍蜷', '浊响', '清晰', '稍凹', '软粘', 0.403, 0.237, 1],
        ['乌黑', '稍蜷', '浊响', '稍糊', '稍凹', '软粘', 0.481, 0.149, 1],
        ['乌黑', '稍蜷', '浊响', '清晰', '稍凹', '硬滑', 0.437, 0.211, 1],
        ['乌黑', '稍蜷', '沉闷', '稍糊', '稍凹', '硬滑', 0.666, 0.091, 0],
        ['青绿', '硬挺', '清脆', '清晰', '平坦', '软粘', 0.243, 0.267, 0],
        ['浅白', '硬挺', '清脆', '模糊', '平坦', '硬滑', 0.245, 0.057, 0],
        ['浅白', '蜷缩', '浊响', '模糊', '平坦', '软粘', 0.343, 0.099, 0],
        ['青绿', '稍蜷', '浊响', '稍糊', '凹陷', '硬滑', 0.639, 0.161, 0],
        ['浅白', '稍蜷', '沉闷', '稍糊', '凹陷', '硬滑', 0.657, 0.198, 0],
        ['乌黑', '稍蜷', '浊响', '清晰', '稍凹', '软粘', 0.360, 0.370, 0],
        ['浅白', '蜷缩', '浊响', '模糊', '平坦', '硬滑', 0.593, 0.042, 0],
        ['青绿', '蜷缩', '沉闷', '稍糊', '稍凹', '硬滑', 0.719, 0.103, 0]
        ]
    features=['色泽','根蒂', '敲声', '纹理', '脐部', '触感', '密度', '含糖量']
    numList=[]
    for i in range(len(features)-2):
        numList.append(len(featureDic[features[i]]))
    dataSet=np.array(dataSet)
    #print(dataSet)
    return dataSet,features

def cntProLap(dataSet,index,value,classLabel,N):
    """
    用拉普拉斯修正估计概率值
    :param dataSet:
    :param index:
    :param value:
    :param classLabel:
    :param N:
    :return:
    """
    extData=dataSet[dataSet[:,-1]==classLabel]
   # print(extData)
    cnt=0
    for data in extData:
        if data[index]==value:
            cnt +=1
    #print((cnt+1)/(float(len(extData))+N))
    return  (cnt+1)/(float(len(extData))+N)
    

def naiveBayesClassifier(dataSet,features):
    """
     拉普拉斯修正的朴素贝叶斯分类器。所谓拉普拉斯修正的意义在于，避免训练集中某些
     属性没有出现，导致概率为零，而使得整个连乘为零。
    修正的方法是：
        1.对于类c(好瓜/坏瓜)的先验概率(样本中的 P(c=好瓜)/P(c=坏瓜)),分子加1，
        分母加类别数，本题中两类所以为2。
        2.对于条件概率(P(xi|c), xi表示第i个属性取值为x的值)，分子加1，分母加第i个
        属性可能的取值数。
    :param dataSet:     训练集
    :param features:    特征列表。['色泽', '根蒂', '敲声', '纹理', '脐部', 
                              '触感', '密度', '含糖量']
    :return:            一个字典，保存了3部分内容。
                        1.对于类别型的变量，保存其是好瓜和不是好瓜的概率。
                        2.对于数值型的属性，保存其实好瓜和不是好瓜的均值和方差。
                        3.保存了类别的先验概率。即P(c=好瓜)和P(c=坏瓜)。
    """
    dict={}
    for feature in  features:
        index=features.index(feature)
        #print(index)
        dict[feature]={}
        if feature !='密度' and feature !='含糖量':
            featIList=featureDic[feature]
            for value in featIList:
                PisCond=cntProLap(dataSet, index, value, '1', len(featIList))
                #print(PisCond)
                pNoCond=cntProLap(dataSet, index, value, '0', len(featIList))
                #print(pNoCond)
                dict[feature][value]={}
                dict[feature][value]["是"]=PisCond
                dict[feature][value]["否"]=pNoCond
            #print(dict)
        else:
            for label in ['1','0']:
                dataExtra=dataSet[dataSet[:,-1]==label]
                #print(dataExtra)
                #将好瓜和坏瓜的含糖量和密度分出来
                extr=dataExtra[:,index].astype("float64")
                #print(extr)
                aver=extr.mean()
                #print(aver)
                var=extr.var() 
                #print(var)
                
                labelStr=""
                if label=="1":
                    labelStr="是"
                else:
                    labelStr="否"
                #因为含糖量和密度是线性值，所以转换为非线性值，按平均值和方差来分
                dict[feature][labelStr]={}
                dict[feature][labelStr]["平均值"]=aver
                dict[feature][labelStr]["方差"]=var
                #print(dict)
    
    length=len(dataSet)
    #将最后一列标签转换成列表
    classLabels=dataSet[:,-1].tolist()
    #print(classLabels)
    dict["好瓜"]={}
    dict["好瓜"]['是']=(classLabels.count('1')+1)/(float(length)+2)
    dict["好瓜"]['否']=(classLabels.count('0')+1)/(float(length)+2)
   # print(dict)
    
    return dict

def NormDist(mean,var,xi):
    """
    计算连续属性的概率密度。
    :param mean:    第c类在第i个属性上的均值
    :param var:     第c类在第i个属性上的方差
    :param xi:      第c类在第i个属性上的取值
    :return:        概率密度
    """
   # print(exp(-((float(xi)-mean)**2)/(2*var))/(sqrt(2*pi*var)))
   #计算每一个的概率密度
    return exp(-((float(xi)-mean)**2)/(2*var))/(sqrt(2*pi*var))

def predict(data,features,bayesDis):
    """
    通过贝叶斯预测数据的类型。
    :param data:            待预测的数据。
    :param features:        特征列表。
    :param bayesDis:        字典。
                            对于类别型的变量，保存其是好瓜和不是好瓜的概率。
                            对于数值型的属性，保存其实好瓜和不是好瓜的均值和方差。
    :return:                预测类型值。
    """
    pGood=bayesDis['好瓜']['是']
    pBad=bayesDis['好瓜']['否']
    for feature in features:
        index=features.index(feature)
        if feature !='密度' and feature !='含糖量':
            pGood *=bayesDis[feature][data[index]]['是']
            pBad *=bayesDis[feature][data[index]]['否']
        else:
            pGood *=NormDist(bayesDis[feature]['是']['平均值'], 
                             bayesDis[feature]['是']['方差'], data[index])
            pBad *=NormDist(bayesDis[feature]['否']['平均值'], 
                             bayesDis[feature]['否']['方差'], data[index])
            
    retClass=""
    if pGood>pBad:
        retClass="好瓜"
    else:
        retClass="坏瓜"
       
   # print(pGood,pBad,retClass)
        
    return pGood,pBad,retClass

def calcAccRate(dataSet,features,bayesDis):
    """
    计算训练集在朴素贝叶斯分类器上的准确率。
    :param dataSet:
    :param features:
    :param bayesDis:
    :return:
    """
    cnt=0.0
    for data in dataSet:
       _,_,pre=predict(data, features, bayesDis)
       if (pre == '好瓜' and data[-1] == '1') \
            or (pre == '坏瓜' and data[-1] == '0'):
            cnt += 1
    #print(cnt/float(len(dataSet)))
    return cnt/float(len(dataSet))

dataSet,features=getDateSet()
dic=naiveBayesClassifier(dataSet, features)
print(dic)
p1,p0,pre=predict(dataSet[0], features, dic)
print(f"p1={p1}")
print(f"p0={p0}")
print(f"pre={pre}")
print("Train data set acc=",calcAccRate(dataSet, features, dic))


