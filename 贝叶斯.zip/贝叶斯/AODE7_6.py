# -*- coding: utf-8 -*-
"""
Created on Tue Aug  3 19:45:36 2021

@author: cui
"""
import numpy as np
import matplotlib.pyplot as plt
from pylab import *
import operator

#特征字典
featureDic={
    '色泽': ['浅白', '青绿', '乌黑'],
    '根蒂': ['硬挺', '蜷缩', '稍蜷'],
    '敲声': ['沉闷', '浊响', '清脆'],
    '纹理': ['清晰', '模糊', '稍糊'],
    '脐部': ['凹陷', '平坦', '稍凹'],
    '触感': ['硬滑', '软粘']
    }

def getDataSet():
    """
    处理数据，编码好数据集和特征字典
    """
    dataSet=[
        ['青绿', '蜷缩', '浊响', '清晰', '凹陷', '硬滑', 0.697, 0.460, 1],
        ['乌黑', '蜷缩', '沉闷', '清晰', '凹陷', '硬滑', 0.774, 0.376, 1],
        ['乌黑', '蜷缩', '浊响', '清晰', '凹陷', '硬滑', 0.634, 0.264, 1],
        ['青绿', '蜷缩', '沉闷', '清晰', '凹陷', '硬滑', 0.608, 0.318, 1],
        ['浅白', '蜷缩', '浊响', '清晰', '凹陷', '硬滑', 0.556, 0.215, 1],
        ['青绿', '稍蜷', '浊响', '清晰', '稍凹', '软粘', 0.403, 0.237, 1],
        ['乌黑', '稍蜷', '浊响', '稍糊', '稍凹', '软粘', 0.481, 0.149, 1],
        ['乌黑', '稍蜷', '浊响', '清晰', '稍凹', '硬滑', 0.437, 0.211, 1],
        ['乌黑', '稍蜷', '沉闷', '稍糊', '稍凹', '硬滑', 0.666, 0.091, 0],
        ['青绿', '硬挺', '清脆', '清晰', '平坦', '软粘', 0.243, 0.267, 0],
        ['浅白', '硬挺', '清脆', '模糊', '平坦', '硬滑', 0.245, 0.057, 0],
        ['浅白', '蜷缩', '浊响', '模糊', '平坦', '软粘', 0.343, 0.099, 0],
        ['青绿', '稍蜷', '浊响', '稍糊', '凹陷', '硬滑', 0.639, 0.161, 0],
        ['浅白', '稍蜷', '沉闷', '稍糊', '凹陷', '硬滑', 0.657, 0.198, 0],
        ['乌黑', '稍蜷', '浊响', '清晰', '稍凹', '软粘', 0.360, 0.370, 0],
        ['浅白', '蜷缩', '浊响', '模糊', '平坦', '硬滑', 0.593, 0.042, 0],
        ['青绿', '蜷缩', '沉闷', '稍糊', '稍凹', '硬滑', 0.719, 0.103, 0]
                ]
    features=['色泽', '根蒂', '敲声', '纹理', '脐部', '触感', '密度', '含糖量']
    #每种特征属性的个数
    numList=[]#次数的numList必须定义成数组
    for i in range(len(features)-2):
        numList.append(len(featureDic[features[i]]))

    dataSet=np.array(dataSet)    
    return dataSet,features

def AODE(dataSet,data,features):
    """
    AODE(Averaged One-Dependent Estimator)。
    意思为尝试将每个属性作为超父来构建SPODE。
    :param dataSet:
    :param data:
    :param features:
    :return:
    """
    m,n=dataSet.shape
    #特征不取连续值的属性，如密度和含糖量
    n=n-3
    #保存三个值。好瓜的可能性，坏瓜的可能性，和预测的值。
    pDir={}
    for classLabel in ["好瓜","坏瓜"]:
        P=0.0
        if classLabel=="好瓜":
            sign='1'
        else:
            sign='0'
        # 抽出类别为sign的数据
        extrDataSet=dataSet[dataSet[:,-1]==sign]
        #print(extrDataSet)
        # 对于第i个特征
        for i in range(n):
            xi=data[i]
            #print(xi)
            #计算classLabel类，第i个属性上取值为xi的样本对总数据集的占比
            Dcxi=extrDataSet[extrDataSet[:,i]==xi]# 第i个属性上取值为xi的样本数
            #print(Dcxi)
            Ni=len(featureDic[features[i]])# 第i个属性可能的取值数
            #print(Ni)
            Pcxi=(len(Dcxi)+1)/float(m+2*Ni)
            #print(Pcxi)
            #计算类别为c且在第i和第j个属性上分别为xi和xj的样本
            #对于类别为c属性为xi的样本的占比
            mulPCond=1
            for j in range(n):
                xj=data[j]
                #print(xj)
                Dcxij=Dcxi[Dcxi[:,j]==xj]
                #print(Dcxij)
                Nj=len(featureDic[features[j]])
                #print(Nj)
                PCond=(len(Dcxij)+1)/float(len(Dcxi)+Nj)
                #print(PCond)
                mulPCond *=PCond
                #print(mulPCond)
            P +=Pcxi*mulPCond
            #print(P)
        pDir[classLabel]=P
        #print(pDir)
        
    if pDir["好瓜"] > pDir["坏瓜"]:
        preClass="好瓜"
    else:
        preClass="坏瓜"
        
    #print(pDir["好瓜"],pDir["坏瓜"],preClass)
    return pDir["好瓜"],pDir["坏瓜"],preClass

def calcAccRate(dataSet,features):
    """
     计算准确率
    """
    cnt=0
    for data in dataSet:
       _,_,pre=AODE(dataSet, data, features)
       if (pre == '好瓜' and data[-1] == '1') \
            or (pre == '坏瓜' and data[-1] == '0'):
            cnt += 1
    #print(cnt/float(len(dataSet)))
    return cnt/float(len(dataSet))

def main():
    dataSet,features=getDataSet()
    pG,pB,pre=AODE(dataSet,dataSet[0],features)
    print("pG=",pG)
    print("pB=",pB)
    print("pre=",pre)
    print("real class=",dataSet[0][-1])
    print(calcAccRate(dataSet, features))
    
if __name__=='__main__':
    main()
            
    
    
    
    
  

