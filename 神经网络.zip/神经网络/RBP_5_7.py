# -*- coding: utf-8 -*-
"""
Created on Thu Jul 29 23:30:32 2021

@author: cui
"""
import numpy as np
import matplotlib.pyplot as plt

def getData():
    """
    取得异或数据
    """
    dataSet=[
        [0, 0, 0],
        [0, 1, 1],
        [1, 1, 0],
        [1, 0, 1]
        ]
    return np.array(dataSet)

def RBFNN(dataSet,eta,thresh):
    """
    训练RBF网络
    :param dataSet: 数据集
    :param eta:     学习率
    :param thresh:  错误率容忍度
    :return: w,     隐层神经元对应的权重
             c,     隐层神经元对应的中心
            beta,   高斯径向基函数里的参数
          errHistory  训练的历史错误率
    """
    # 记录每轮迭代的均方误差
    errHistory=[]
    #y是最后一列的标签数据
    y=dataSet[:,-1]
    print(y)
    #X是0到倒数第二列的值
    x=dataSet[:,:-1]
    print(x)
    #计算有多少行多少列
    m,n=x.shape
    print(m,n)
    
    #隐藏神经元个数
    t=10
    #初始化
    c=np.random.rand(t,n)
    #初始化beta
    beta=np.random.randn(1,t)
    #初始化w
    w=np.random.rand(1,t)
    err=errOfMeanSqur(dataSet,w,c,beta)
    while err>thresh:
        for i in range(m):
            trainX=np.tile(x[i],(t,1))
            dist=((trainX-c)**2).sum(axis=1).reshape(1,-1)
            rho=np.exp(-beta*dist)
            phi=np.dot(w,rho.T)
            
            #计算梯度
            dBeta=-w*(phi-y[i])*rho*dist
            dw=(phi-y[i])*rho
            
            #更新参数
            beta -=eta*dBeta
            w -=eta*dw
            
            #计算新的错误率
            err=errOfMeanSqur(dataSet,w,c,beta)
            errHistory.append(err)
            print(f"iteration {len(errHistory)},err={err}")
    return w,c,beta,errHistory

def classify(data,w,c,beta):
    """
    给定参数分类
    :param data:
    :param w:
    :param c:
    :param beta:
    :return:
    """
    dataArr=np.tile(data,(c.shape[0],1))
    dist=((dataArr-c)**2).sum(axis=1)
    rho=np.exp(-beta*dist).reshape(-1,1)
    return np.dot(w,rho)

def errOfMeanSqur(dataSet,w,c,beta):
    """
    计算平方误差
    :param dataSet:
    :param w:
    :param c:
    :param beta:
    :return:
    """
    x=dataSet[:,:-1]
    y=dataSet[:,-1]
    num=x.shape[0]
    err=0.0
    for i in range(num):
        yPre=classify(dataSet[i][:-1],w,c,beta)
        err +=((y[i]-yPre)**2)/2.0
        
    return (err/float(num))[0][0]
        
def main():
     dataSet=getData()
     w,c,beta,errHistory1=RBFNN(dataSet,0.1,0.001)
     plt.plot(np.arange(len(errHistory1)),errHistory1)
     plt.show()
     
     #测试抑或
     for data in dataSet:
         pre=classify(data[:-1],w,c,beta)
         print(f"data={data[:-1]},label={data[-1]},pre={pre}")
        
if __name__=="__main__":
    main()
    
    



