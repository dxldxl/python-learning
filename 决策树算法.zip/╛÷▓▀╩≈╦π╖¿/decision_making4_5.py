# -*- coding: utf-8 -*-
"""
Created on Tue Jul 27 02:10:46 2021

@author: cui
"""
import numpy as np
import matplotlib.pyplot as pt
from pylab import *
import pandas as pd

#特征字典,此处定义了一个元组，来存储
featureDic = {
    '色泽': ['浅白', '青绿', '乌黑'],
    '根蒂': ['硬挺', '蜷缩', '稍蜷'],
    '敲声': ['沉闷', '浊响', '清脆'],
    '纹理': ['清晰', '模糊', '稍糊'],
    '脐部': ['凹陷', '平坦', '稍凹'],
    '触感': ['硬滑', '软粘']}
    
# ***********************画图***********************
# **********************start***********************
#定义文本箭头和格式
# 决策节点的属性。boxstyle为文本框的类型，sawtooth是锯齿形，fc是边框线粗细
decisionNode=dict(boxstyle="sawtooth",fc="0.8")
#可以写成 dicisionNode={boxstyle:'sawtooth',fc:'0.8'}
#决策树叶子节点的属性
leafNode=dict(boxstyle='round',fc='0.8')
#箭头的属性
arrow_args=dict(arrowstyle='<-')
#汉字显示的必要语句
mpl.rcParams['font.sans-serif']=['SimHei']

#显示负号
#mpl.rcParams['axes.unnicode_serif']=False

#这个是用来绘制线上的标注,在父节点和子节点之间填充注释的文本信息
def plotMidText(cntrPt,parentPt,txtString):
    #不是除以52.0是因为前面父节点与子节点的差值乘以2
    xMid=2*(parentPt[0]-cntrPt[0])/5.0 +cntrPt[0]
    yMid=2*(parentPt[1]-cntrPt[1])/5.0 +cntrPt[1]
    #画文本的函数
    createPlot.ax1.text(xMid,yMid,txtString,fontsize=20)

#这个是用来一注释形式绘制节点和箭头线，
def plotNode(nodeTxt,centerPt,parentPt,nodeType):
    createPlot.ax1.annotate(nodeTxt,
                            xy=parentPt,
                            xycoords="axes fraction",
                            xytext=centerPt,
                            textcoords="axes fraction",
                            va="center",
                            ha="center",
                            bbox=nodeType,
                            arrowprops=arrow_args,
                            fontsize=12)

#获取叶节点的数目
def getNumLeafs(myTree):
    numLeafs=0
    firstStr=list(myTree.keys())[0]
    secondDict=myTree[firstStr]
    for key in secondDict.keys():
        #测试节点是否为字典，如果不是，则为叶节点，是字典就循环向树中遍历
        if type(secondDict[key]).__name__=='dict':
            numLeafs +=getNumLeafs(secondDict[key])
        else:
            numLeafs +=1
    return numLeafs

#获取树的层数
def getTreeDepth(myTree):
    maxDepth=0
    firstStr=list(myTree.keys())[0]
    secondDict=myTree[firstStr]
    for key in secondDict.keys():
        if type(secondDict[key]).__name__=='dict':
            thisPath=1+getTreeDepth(secondDict[key])
        else:
            thisPath=1
    if thisPath > maxDepth: maxDepth=thisPath
    return maxDepth
    
#递归，决定整个树图的绘制，决策树的绘制的工作完成,绘图逻辑
#myTree：树的字典, parentPt:父节点, nodeTxt：节点的文字标注
def plotTree(myTree,parentPt,nodeTxt):
    #使用叶节点的个数，来确定树的宽度
    numLeafs=getNumLeafs(myTree)
    #确定树的宽度
    getTreeDepth(myTree)
    #高度和宽度计算好后，就可以确定绘图的中心点位置
    #节点标签
    firstStr=list(myTree.keys())[0]
     #计算当前节点的位置  
    #使用全局变量plotTree.xOff和plotTree.yOff追踪绘图的位置，放置下一个节点
    cntrPt=(plotTree.xOff+(1.0+float(numLeafs))/2.0/plotTree.totalW,plotTree.yOff)
    #在父子节点间填充文本信息 
    plotMidText(cntrPt, parentPt, nodeTxt)
    #绘制带箭头的注解 
    plotNode(firstStr, cntrPt, parentPt, decisionNode)
    secondDict=myTree[firstStr]
    plotTree.yOff=plotTree.yOff-1.0/plotTree.totalD
    for key in secondDict.keys():
        if  type(secondDict[key]).__name__=='dict':
            #递归
            plotTree(secondDict[key],cntrPt, str(key))
        else:
            plotTree.xOff=plotTree.xOff+1.0/plotTree.totalW
            plotNode(secondDict[key], (plotTree.xOff,plotTree.yOff),
                     cntrPt, leafNode)
            plotMidText((plotTree.xOff, plotTree.yOff), cntrPt,str(key))
        plotTree.yOff=plotTree.yOff+1.0/plotTree.totalD
#如果你得到一个字典，你知道它是一棵树，第一个元素将是另一个字典

#画图
def createPlot(inTree):
    #指定figure的编号并指定figure的大小, 指定线的颜色, 宽度和类型
    fig=plt.figure(1,figsize=(600,30),facecolor='white')
    fig.clf()
    axprops=dict(xticks=[],yticks=[])
    createPlot.ax1=plt.subplot(111, frameon=False,**axprops)
    plotTree.totalW=float(getNumLeafs(inTree))
    plotTree.totalD=float(getTreeDepth(inTree))
    plotTree.xOff=-0.5/plotTree.totalW
    plotTree.yOff=0.9
    plotTree(inTree, (0.5,0.9), '')
    plt.show()

# ***********************画图***********************
# ***********************end************************

def getDataSet():
    """
    get watermelon data set 3.0 alpha.
    :return: 编码好的数据集以及特征的字典。
    """    
    dataSet=[
        ['青绿', '蜷缩', '浊响', '清晰', '凹陷', '硬滑', 0.697, 0.460, 1],
        ['乌黑', '蜷缩', '沉闷', '清晰', '凹陷', '硬滑', 0.774, 0.376, 1],
        ['乌黑', '蜷缩', '浊响', '清晰', '凹陷', '硬滑', 0.634, 0.264, 1],
        ['青绿', '蜷缩', '沉闷', '清晰', '凹陷', '硬滑', 0.608, 0.318, 1],
        ['浅白', '蜷缩', '浊响', '清晰', '凹陷', '硬滑', 0.556, 0.215, 1],
        ['青绿', '稍蜷', '浊响', '清晰', '稍凹', '软粘', 0.403, 0.237, 1],
        ['乌黑', '稍蜷', '浊响', '稍糊', '稍凹', '软粘', 0.481, 0.149, 1],
        ['乌黑', '稍蜷', '浊响', '清晰', '稍凹', '硬滑', 0.437, 0.211, 1],
        ['乌黑', '稍蜷', '沉闷', '稍糊', '稍凹', '硬滑', 0.666, 0.091, 0],
        ['青绿', '硬挺', '清脆', '清晰', '平坦', '软粘', 0.243, 0.267, 0],
        ['浅白', '硬挺', '清脆', '模糊', '平坦', '硬滑', 0.245, 0.057, 0],
        ['浅白', '蜷缩', '浊响', '模糊', '平坦', '软粘', 0.343, 0.099, 0],
        ['青绿', '稍蜷', '浊响', '稍糊', '凹陷', '硬滑', 0.639, 0.161, 0],
        ['浅白', '稍蜷', '沉闷', '稍糊', '凹陷', '硬滑', 0.657, 0.198, 0],
        ['乌黑', '稍蜷', '浊响', '清晰', '稍凹', '软粘', 0.360, 0.370, 0],
        ['浅白', '蜷缩', '浊响', '模糊', '平坦', '硬滑', 0.593, 0.042, 0],
        ['青绿', '蜷缩', '沉闷', '稍糊', '稍凹', '硬滑', 0.719, 0.103, 0]
        ]
    features=['色泽', '根蒂', '敲声', '纹理', '脐部', '触感', '密度', '含糖量']

    # features = ['color', 'root', 'knocks', 'texture', 'navel', 'touch', 'density', 'sugar']

    # #得到特征值字典，本来用这个生成的特征字典，还是直接当全局变量方便
    # featureDic = {}
    # for i in range(len(features)):
    #     featureList = [example[i] for example in dataSet]
    #     uniqueFeature = list(set(featureList))
    #     featureDic[features[i]] = uniqueFeature

    # 每种特征的属性个数
    numList = []  # [3, 3, 3, 3, 3, 2]
    for i in range(len(features) - 2):
        numList.append(len(featureDic[features[i]]))

    dataSet = np.array(dataSet)
    #取最后一列，数据的标签值，来进行分类
    return dataSet[:, :-1], dataSet[:, -1], features
# data, classLabel, feature = getDataSet()
# print(data)
# print(classLabel)
# print(feature)

def newData():
    """
    利用pandas将分类变量转化为数值变量。将分类变量进行one-hot编码。
    :return: 变量全为数值的变量，以及新的特征标签。
    """
    dataSet,classLabel,features=getDataSet()
    df=pd.DataFrame(dataSet)
    df.columns=features
    #类别变量转化为数字变量
    # features = ['色泽', '根蒂', '敲声', '纹理', '脐部', '触感', '密度', '含糖量']
    # features = ['color', 'root', 'knocks', 'texture', 'navel', 'touch', 'density', 'sugar']
    # 色泽
    color=pd.get_dummies(df.色泽,prefix="色泽")
    #根蒂
    root=pd.get_dummies(df.根蒂,prefix="根蒂")
    #敲声
    knocks = pd.get_dummies(df.敲声, prefix="敲声")
    # 纹理
    texture = pd.get_dummies(df.纹理, prefix="纹理")
    # 脐部
    navel = pd.get_dummies(df.脐部, prefix="脐部")
    # 触感
    touch = pd.get_dummies(df.触感, prefix="触感")
    #含糖量和密度
    densityAndsugar=pd.DataFrame()
    densityAndsugar['密度']=df.密度
    densityAndsugar['含糖量']=df.含糖量
    #融合
    newData=pd.concat([color,root,knocks, texture, navel, touch, densityAndsugar],axis=1)
    newFeatures=list(newData.columns)
    newData=np.asarray(newData,dtype="float64")
    classLabel=np.asarray(classLabel,dtype="int").reshape(-1,1)
    
    #新的特征数据和类融合
    newDataSet=np.concatenate((newData,classLabel),axis=1)
    #在第一列添加1
    newDataSet=np.insert(newDataSet,0,np.ones(dataSet.shape[0]),axis=1)
    return newDataSet,newFeatures
# data, feature = newData()
# print(data)
# print(feature)

#对率回归
def sigmoid(z):
    return 1.0/(1+np.exp(-z))

#牛顿法计算逻辑参数
def newton(dataArr,labelArr):
    """
     dataArr:输入数据集的格式（M,N）
     labelArr：数据的标签格式（M，1）
     return:返回牛顿方法获得的参数
    """
    m,n=dataArr.shape
    labelArr=labelArr.reshape(-1,1)
    beta=np.ones((n,1))
    #存储历史错误
    errList=[]
    
    z=np.dot(dataArr,beta)
    oldLbeta=0
    newLBetaMat = -labelArr * z + np.log(1 + sigmoid(z))
    newLBeta = np.sum(newLBetaMat)
    it = 0
    while abs(oldLbeta - newLBeta) > 1e-5:
        it += 1
        # py0 = p(y=0|x) with shape (m,1)
        py0 = sigmoid(-np.dot(dataArr, beta))
        py1 = 1 - py0
        # 'reshape(n)' get shape (n,); 'np.diag' get diagonal matrix with shape (m,m)
        p = np.diag((py0 * py1).reshape(m))

        # shape (m,n)
        dBetaMat = -dataArr * (labelArr - py1)
        # first derivative with shape (1, n)
        dBeta = np.sum(dBetaMat, axis=0, keepdims=True)
        # second derivative with shape (n, n)
        dBeta2 = dataArr.T.dot(p).dot(dataArr)
        dBeta2Inv = np.linalg.inv(dBeta2)
        # (n,1) (n,1)          (n,n)    (n,1)
        beta = beta - np.dot(dBeta2Inv, dBeta.T)

        z = np.dot(dataArr, beta)
        oldLbeta = newLBeta
        newLBetaMat = -labelArr * z + np.log(1 + sigmoid(z))
        newLBeta = np.sum(newLBetaMat)

        pre = predict(beta, dataArr)
        errorRate = cntErrRate(pre, labelArr)
        errList.append(errorRate)
    print("newton iteration is ", it)
    return beta, errList
    
def gradDescent(dataArr,labelArr,alpha,T):
    """
    通过梯度下降计算逻辑参数
    :param dataArr: input data set with shape (m, n)
    :param labelArr: the label of data set with shape (m, 1)
    :param alpha: step length (learning rate)
    :param T: iteration
    :return: parameters
    """
    m,n=dataArr.shape
    labelArr=labelArr.reshape(-1,1)
    # errList = []
    beta=np.ones((n,1))
    for t in range(T):
         # py0 = p(y=1|x) with shape (m,1)
        py1 = sigmoid(np.dot(dataArr, beta))
        dBetaMat = -dataArr * (labelArr - py1)
        # shape (1,n)
        dBeta = np.sum(dBetaMat, axis=0, keepdims=True)
        beta -= alpha * dBeta.T

        # test code
        # pre = predict(beta, dataArr)
        # errorRate = cntErrRate(pre, labelArr)
        # errList.append(errorRate)

    return beta
# dataSet, features = newData()
# testBeta = gradDescent(dataSet[:, :-1], dataSet[:, -1], 0.1, 500)
# print(testBeta)    
    
#预测
def predict(beta,dataArr):
    preArr=sigmoid(np.dot(dataArr,beta))
    preArr[preArr>0.5]=1
    preArr[preArr<=0.5]=0
    return preArr

#统计错误率
def cntErrRate(preLabel,label):
    """
    :param preLabel: predict label
    :param label: real label
    :return: error rate
    """
    m=len(preLabel)
    cnt=0.0
    for i in range(m):
        if preLabel[i]!=label[i]:
            cnt+=1.0
        return cnt / float(m)
   
#返回最大的特征和对应的值
def majorityCnt(classList):
    classCount={}
    for vote in classList:
        if vote not in classCount:
            classCount[vote]=0
        classCount[vote]+=1
# classCount.items()将字典的key-value对变成元组对，如{'a':1, 'b':2} -> [('a',1),('b',2)]
# operator.itemgetter(1)按照第二个元素次序进行排序
# reverse=True表示从大大到小。[('b',2), ('a',1)]  
    sortedClassCount=sorted(classCount.items(),key=operator.itemgetter(1),reverse=True)
    #返回第0个元组的第0个值
    return sortedClassCount[0][0]

#划分数据
def splitDataSet(dataSet,bestBeta):
    """
    将数据分为两部分
    :param dataSet:
    :param bestBeta:
    :return:
    """
    dot=np.dot(dataSet[:,:-1], bestBeta).flatten()
    dataSet1=dataSet[dot <=0]
    dataSet2=dataSet[dot >0]
    return dataSet1,dataSet2

# # 用来保存beta
# class TreeNode:
#     def __init__(self):
#         self.beta = beta
#         self.classLabel = -1
#         self.left = None
#         self.right = None
# 定义节点类的版本，这一版本在节点处保存权重，容易计算精确度。
# def createTreeV2(dataSet, features):
#     classList = dataSet[:, -1].tolist()
#     if classList.count(classList[0]) == len(classList):
#         leaf = TreeNode()
#         leaf.classLabel = classList[0]
#         return leaf
#     if len(dataSet[0]) == 1:
#         leaf = TreeNode(-1)
#         leaf.classLabel = majorityCnt(classList)
#         return leaf
#
#     bestBeta = gradDescent(dataSet[:, :-1], dataSet[:, -1], 0.1, 500)
#
#     Node = TreeNode()
#     subDataIs, subDataNotIs = splitDataSet(dataSet, bestBeta)
#     Node.left = createTreeV2(subDataIs, features)
#     Node.right = createTreeV2(subDataNotIs, features)
#
#     return Node

def createTree(dataSet, features):
    #将数据矩阵转换成列表
    classList = dataSet[:, -1].tolist()
    if classList.count(classList[0]) == len(classList):
        return classList[0]
    if len(dataSet[0]) == 1:
        return majorityCnt(classList)

    bestBeta = gradDescent(dataSet[:, :-1], dataSet[:, -1], 0.1, 500)
    # 得到节点txt
    txt = ""
    for i in range(len(bestBeta)):
        if i == 0:
            continue
        if bestBeta[i] > 0:
            txt += "+" + str(bestBeta[i][0]) + "x" + features[i - 1] + '\n'
        else:
            txt += str(bestBeta[i][0]) + "x" + features[i - 1] + '\n'
    txt += "<=" + str(-bestBeta[0][0])

    myTree = {txt: {}}
    subDataIs, subDataNotIs = splitDataSet(dataSet, bestBeta)
    myTree[txt]['是'] = createTree(subDataIs, features)
    myTree[txt]['否'] = createTree(subDataNotIs, features)

    return myTree


def main():
    dataSet, features = newData()
    myTree = createTree(dataSet, features)
    print(myTree)
    createPlot(myTree)

#执行函数
if __name__=='__main__':
    main()


