# -*- coding: utf-8 -*-
"""
Created on Mon Jul 26 19:23:21 2021

@author: cui
"""
import numpy as np
from sklearn.metrics import classification_report
from functools import reduce
#将表4.3中的数据进行了翻译，并去除了密度和含糖率两个特征值,创建数据矩阵（二维）
dataset=np.array([[0,0,0,0,0,0,1],
                    [1,0,1,0,0,0,1],
                    [1,0,0,0,0,0,1],
                    [0,0,1,0,0,0,1],
                    [2,0,0,0,0,0,1],
                    [0,1,0,0,1,1,1],
                    [1,1,0,1,1,1,1],
                    [1,1,0,0,1,0,1],
                    [1,1,1,1,1,0,0],
                    [0,2,2,0,2,1,0],
                    [2,2,2,2,2,0,0],
                    [2,0,0,2,2,1,0],
                    [0,1,0,1,0,0,0],
                    [2,1,1,1,0,0,0],
                    [1,1,0,0,1,1,0],
                    [2,0,0,2,2,0,0],
                    [0,0,1,1,1,0,0]]
                     )
#获取训练数据
train_dataset=[]
#生成标签序列0至16
a=set(range(17))
#print(a)
b={3,4,7,8,10,11,12}
c=a-b
#print(c)
for i in list(c):
    train_dataset.append(dataset[i])
train_dataset=np.array(train_dataset)
#print(train_dataset)

#取得测试数据
test_dataset=[]
for i in list(b):
    test_dataset.append(dataset[i])
#print(test_dataset)
test_dataset=np.array(test_dataset)
#print(test_dataset)

#4.3 基尼指数生成决策树2.0（CART）
#计算特征值对应的Gini指数，计算一个特征的一个特征值对应的Gini值
def calGini(dataset):
    count0=0
    count1=0
    #也可以用shape[0]来获取数组的长度
    numdataset=len(dataset)
    for ai_dataset in dataset:
        #扫描数据的最后一列，也就是数据的标签列，来计算所出的概率
        ai_label=ai_dataset[-1]
        #判断好瓜和坏瓜的数据多少
        if ai_label==1:
            count1 +=1
        else:
            count0 +=1
    prob1=(float)(count1)/numdataset
    prob2=(float)(count0)/numdataset
    Gini=1-(prob1**2+prob2**2)
    return Gini
    
#计算特征的Gini指数，主要是计算每个特征的所占比例
def calAGain(dataset,i):
    dataset=np.array(dataset)
    #获取列表标签
    a_dataset=dataset[:,i]
    #print(a_dataset)
    # 创建一个与a_dataset相同的列表,为空
    values=list(set(a_dataset))
   # print(values)
    Dv_Gini=0
    #循环每一个特征
    for ai in values:
        ai_dataset=[]
        #使用range创建一个与dataset行数长度相同的一维列表
        for j in range(len(dataset)):
           # print(a_dataset[j])
            if ai==a_dataset[j]:
                #循环每一个特征列,这里的ai_dataset是每一个特征构成的列表
                ai_dataset.append(dataset[j])
       # print(ai_dataset)
        num_ai=len(ai_dataset)
       # print(num_ai)
        Gini=calGini(ai_dataset)
        prob=float(num_ai)/len(dataset)
        #公式中的求和
        Dv_Gini +=prob*Gini
    return Dv_Gini
        
#选择Gini最小的特征
def choosenbestGini(dataset):
    #特征的多少，也就是数组的列数
    numA=len(dataset[0])
    #定义一个元组，来存储每一个特征的基尼指数
    a_Gini_dict={}
    for i in range(numA-1):
        a_Gini_dict[i]=calAGain(dataset, i)
    #a_Gini_dict.items()为待排序对象，key=lambda 
    #x:x[1]为待排序对象的第二维进行排序,默认升序排列
    #从第一个元素开始，将元组转换成列表
    #在这里，list将a_Gini_dict元组中的所有数据都转换成了a_Gini_list列表中的值
    a_Gini_list = list(sorted(a_Gini_dict.items(),key=lambda x:x[1]))[0]
    #print(a_Gini_list)
    #因此，在此处，所得的列表标签0是特征值，标签1是最小的gini指数
    min_a_Gini_i=a_Gini_list[0]
    min_a_Gini_value=a_Gini_list[1]
    return min_a_Gini_i,min_a_Gini_value

#去除父节点的特征数据
def splitdataset(dataset,axis,value):
    retdataset=[]
    for featvec in dataset:
        if featvec[axis]==value:
            reducefeatvec = np.hstack((featvec[:axis],featvec[axis+1:]))
            retdataset.append(reducefeatvec)
            
    return retdataset

#生成label列表
labels=['color','root','sound','textile','belly','feel']

#生成决策树
def TREE(dataset,labels):
    #将dataset中的数据先按行依次放入example中，
    #然后取得example中的example[-1]元素，放入列表classList中
    #也就是将数据放入example后取出每一行特征值的标记
    classlist=[example[-1] for example in dataset]
    #print(classlist)
    if classlist.count(classlist[0])==len(classlist):
        return classlist[0]
    #得到最小基尼指数的特征值和基尼指数
    bestA,bestGini=choosenbestGini(dataset)
    bestfeatlabel=labels[bestA]
    mytree={bestfeatlabel:{}}
    #删除已经用于绘制决策树的标签
    del(labels[bestA])
    #将之后的特征中基尼指数高的放入featvalues列表中
    featvalues=[example[bestA] for example in dataset]
    #删除列表featvalues中的重复数据
    uniquevals=set(featvalues)
    for value in uniquevals:
        sublabels=labels[:]
        #不断的重复画树节点
        mytree[bestfeatlabel][value]=TREE(splitdataset(dataset,bestA,value), sublabels)
    return mytree

a=TREE(dataset, labels)
#print(a)

test_label=test_dataset[-1]
train_test_label=[]

#根据生成的树编写分便器，例题深度少，可以这么写，深度多就不行

#创建特征名称的字典
labels=['color','root','sound','textile','belly','feel']
labels_dict={}
for i in labels:
    labels_dict[i]=labels.index(i)
    
def train_test_label(dataset):
    train_test_label_list=[]
    for vector in dataset:
         if vector[labels_dict['color']] == 0:
            if vector[labels_dict['sound']] == 0:
                train_test_label_list.append(1)
            else:train_test_label_list.append(0)
         elif vector[labels_dict['color']] == 1:
            if vector[labels_dict['root']] == 0:
                train_test_label_list.append(1)
            elif vector[labels_dict['root']] == 1:
                if vector[labels_dict['textile']] == 0:
                    train_test_label_list.append(0)
                elif vector[labels_dict['textile']] == 1:
                    train_test_label_list.append(0)
                else:train_test_label_list.append(5)
            else:train_test_label_list.append(5)
         else:train_test_label_list.append(0)
    return train_test_label_list
        
#得到测试结果
test_result0=train_test_label(dataset)

#计算正确率
#比较正确率可以使用已有的包classification_report
def calrightrate(test_result,real_result):
    #测试数据的向量数
    num=len(test_result)
    count=0
    for i in range(num):
        if test_result[i]==real_result[i]:
            count +=1
    right_rate=float(count)/num
    
    """
    for i in range(len(test_result)):
        max_value=max(test_result[i])
        for j in range(len(test_result[i])):
            if max_value==test_result[i][j]:
                test_result[i][j]=1
            else:
                test_result[i][j]=0
                
    right_rate_1=classification_report(test_dataset, test_result,digits=3)
    return right_rate,right_rate_1
    """
    
    return right_rate

#预剪枝
#color层 color=？ 定义为1(好) 测试集的概率
num=len(test_dataset)
num0floor=list(test_dataset[-1]).count(1)
rightrate=float(num0floor)/num  

#color 0,1,2 : 1,1,0(好 好 坏)
#color值对应的好瓜坏瓜，应该根据训练集color 0/1/2 对应的好瓜坏瓜数量确定 取多的定义
#这里就不写程序计算训练集每个结点的好坏个数了
#计算测试集剪枝后的正确率    
num1floor = 0
for vector in test_dataset:
    if vector[labels_dict['color']] == 0 and vector[-1] ==1:
        num1floor +=1
    elif vector[labels_dict['color']] == 1 and vector[-1] ==1:
        num1floor +=1
        #此处没有懂为什么是坏瓜还要加1
    elif vector[labels_dict['color']] == 2 and vector[-1] ==0:
        num1floor +=1
right1rate = float(num1floor)/num
    
def cnt(right0,right1):
    if right1 <= right0:
        return "保留"
    else:
       return "剪去"
    
print(cnt(rightrate, right1rate))
 

#后剪枝
#用了一个很慢的方法做后剪枝，剪完一个枝直接得到了100%的正确率（主要还是因为数据太少了）
def latejudge(dataset):
    #决策树的预测结果
    all_test_result=np.array(train_test_label(dataset))
    #实际结果
    real_result=dataset[-1]
    #计算未剪枝的正确率
    right_rate = calrightrate(all_test_result,real_result)
    print(right_rate)
    judge_dataset=[]
    label_num=[]
    m=0
    for vector in dataset:
        m+=1
        if vector[labels_dict['color']] == 0 and vector[labels_dict['root']]==1:
            judge_dataset.append(vector)
            label_num.append(m-1)
    count0 =list(judge_dataset[-1]).count(0)
    count1 =list(judge_dataset[-1]).count(1)
    if count0>count1:
        a=0
    elif count0 == count1:
        a = np.random.randint(0,2,1)
    else:a=1

    for n in label_num:
        test_label[n] = a
    cnt1tree_rate = calrightrate(test_label,real_result) #计算减枝后的正确率
    if cnt1tree_rate > right_rate:
        print(cnt1tree_rate)
latejudge(test_dataset)



#对比预剪枝和后剪枝,后剪枝保留了更多的节点,并且正确率要高于预剪枝，泛化性更好
#但是预剪枝时间成本更低




























