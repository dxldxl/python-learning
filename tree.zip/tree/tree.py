from math import log
import operator
import pickle

#创建数据
def createDataSet():
    dataSet = [[1,1,'yes'],
               [1,1,'yes'],
               [1,0,'no'],
               [0,1,'no'],
               [0,1,'no']]
    labels = ['no surfacings','flippers']
    return dataSet,labels

#计算香农熵
def calcShannonEnt(dataSet):
    numEntries = len(dataSet)
    # print(numEntries)
    labelCounts = {}
    # print(labelCounts)
    for featVec in dataSet:
        # print(featVec)
        currentLabel = featVec[-1]
        # print(currentLabel)
        if currentLabel not in labelCounts.keys():
            labelCounts[currentLabel] = 0
            # print(labelCounts)
            # break
        labelCounts[currentLabel] += 1
    # print(labelCounts)
    shannonEnt = 0.0
    for key in labelCounts:
        prob = float((labelCounts[key])/numEntries)
        shannonEnt -= prob * log(prob,2)
    return shannonEnt

#按照给定的特征划分数据集
def splitDataSet(dataSet, axis, value):
    retDataSet = []
    for featVec in dataSet:
        if featVec[axis] == value:
            reducedFeatVec = featVec[:axis]
            # print(reducedFeatVec)
            reducedFeatVec.extend(featVec[axis + 1:])
            retDataSet.append(reducedFeatVec)
    return retDataSet

#选择数据划分方式
def chooseBestFeatureToSplit(dataSet):
    numFeatures = len(dataSet[0]) - 1
    # print(numFeatures)
    baseEntropy = calcShannonEnt(dataSet)
    # print(baseEntropy)
    bestInfoGain = 0.0; bestFeature = -1
    for i in range(numFeatures):
        featList = [example[i] for example in dataSet]
        # print(featList)
        uniquevals = set(featList)
        # print(uniquevals)
        newEntropy = 0.0
        for value in uniquevals:
            # print(value)
            # print(i)
            subDataSet = splitDataSet(dataSet, i, value)
            # print(subDataSet)
            prob = len(subDataSet) / float(len(dataSet))
            newEntropy += prob * calcShannonEnt(subDataSet)
            # print(newEntropy)
        infoCain = baseEntropy - newEntropy
        # print(infoCain)
        if (infoCain > bestInfoGain):
            bestInfoGain = infoCain
            bestFeature = i
    return bestFeature

#返回出现次数最多的分类可以名称
def majorityCbt(classList):
    classCount = {}
    for vote in classList:
        if vote not  in classCount.keys():
         classCount[vote] = 0
    classCount[vote] += 1
    sortedClassCount = sorted(classCount.items(),key=operator.itemgetter(1),reverse=True)
    return sortedClassCount[0][0]

#创建数的代码
def createTree(dataSet,labels):
    classList = [example[-1] for example in dataSet]
    # print(classList)
    # print(classList[0])
    if classList.count(classList[0]) == len(classList):
        return classList[0]
    if len(dataSet[0]) == 1:
        # print(majorityCbt(classList))
        return majorityCbt(classList)
    bestFeat = chooseBestFeatureToSplit(dataSet)
    # print(bestFeat)
    bestFeatLabel = labels[bestFeat]
    # print(bestFeatLabel)
    myTree = {bestFeatLabel:{}}
    del(labels[bestFeat])
    featValues = {example[bestFeat] for example in dataSet}
    # print(featValues)
    uniqueVals = set(featValues)
    # print(uniqueVals)
    for value in uniqueVals:
        subLabels = labels[:]
        # print(subLabels)
        myTree[bestFeatLabel][value] = createTree(splitDataSet(dataSet,bestFeat,value), subLabels)
    return myTree

#使用决策树进行分类
def classify(inputTree, featLabels, testVec):
    firstStr = list(inputTree.keys())[0]
    secondDict = inputTree[firstStr]
    featIndex = featLabels.index(firstStr)
    for key in secondDict.keys():
        if testVec[featIndex] ==key:
            if type(secondDict[key]).__name__ =="dict": #此处为判断节点将继续进行分类判断
                classLabel = classify(secondDict[key], featLabels, testVec)
            else:
                classLabel = secondDict[key]
    return classLabel

#存储决策树
def storeTree(inputTree,filename):
    fw = open(filename,'w')
    pickle.dump(inputTree,fw)
    fw.close()
def grabTree(filename):
    fr = open(filename)
    return pickle.load(fr)

# dataSet,labels = createDataSet()
# # print(dataSet)
# # print(labels)
# myTree = createTree(dataSet,labels)
# print(myTree)
