import numpy as np
import operator
from tree import *
from treePlotter import *

def treeMain():
    dataSet, labels = createDataSet()
    myTree = createTree(dataSet,labels)
    createPlot(myTree)

# treeMain()
fr = open('lenses.txt')
lenses = [inst.strip().split('\t') for inst in fr.readlines()]
lensesLabels = ['age','prescript', 'astigmatic', 'tearRate']
lensesTree = createTree(lenses,lensesLabels)
print(lensesTree)
createPlot(lensesTree)
