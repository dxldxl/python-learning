import numpy as np
import pandas as pd
from sklearn import datasets  #导入基础训练数据集
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier
from collections import Counter
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import mean_squared_error

#加载数据，并画出散点图
d = datasets.load_iris()
X = d.data[:,2:]
y = d.target
plt.figure()
plt.scatter(X[y == 0,0],X[y == 0,1],color = 'r')
plt.scatter(X[y == 1,0],X[y == 1,1],color = 'g')
plt.scatter(X[y == 2,0],X[y == 2,1],color ='b')
plt.show()

#导入sklearn算法进行分类预测问题实现
dt1 = DecisionTreeClassifier(max_depth=2,criterion="entropy")
dt1.fit(X,y)

# 决策边界输出函数（二维数据点）
def plot_decision_boundary(model,axis):
    x0,x1 = np.meshgrid(
        np.linspace(axis[0],axis[1],int((axis[1] - axis[0])*100)).reshape(-1,1),
        np.linspace(axis[2],axis[3],int((axis[3] - axis[2])*100)).reshape(-1,1)
    )
    print()
    x_new = np.c_[x0.ravel(),x1.ravel()]
    y_pre = model.predict(x_new)
    zz = y_pre.reshape(x0.shape)
    from matplotlib.colors import ListedColormap
    cus = ListedColormap(["#EF9A9A","#FFF59D","#90CAF9"])
    plt.contourf(x0,x1,zz,cmap = cus)

plot_decision_boundary(dt1,axis=(0.5,8,0,3))
plt.scatter(X[y==0,0],X[y==0,1],color = 'r')
plt.scatter(X[y==1,0],X[y==1,1],color='g')
plt.scatter(X[y==2,0],X[y==2,1],color='b')
plt.show()

#定义二分类问题的信息熵计算函数np.sum(-p*np.log(p))
def entropy(p):
    return -p*np.log(p)-(1-p)*np.log(1-p)
x1 = np.linspace(0.01,0.99,100)
y1 = entropy(x1)
plt.plot(x1,y1,"r")
plt.show()

#利用信息熵的原理对数据进行实现划分
def split(x,y,d,value):
    index_a = (x[:,d]<=value)
    index_b = (x[:,d]>value)
    return x[index_a],x[index_b],y[index_a],y[index_b]

def entropy(y):
    Counter1 = Counter(y)
    res = 0.0
    for num in Counter1.values():
        p = num/len(y)
        res += -p*np.log(p)
    return res

def try_split(x,y):
    best_entropy = float("inf")
    best_d,best_v = -1,-1;
    for d in range(x.shape[1]):
        sorted_index = np.argsort(x[:,d])
        for i in range(1,len(x)):
            if x[sorted_index[i-1],d] != x[sorted_index[i],d]:
                v = (x[sorted_index[i-1],d]+ x[sorted_index[i],d])/2
                x_l,x_r,y_l,y_r = split(x,y,d,v)
                e = entropy(y_l) + entropy(y_r)
                if e<best_entropy:
                    best_entropy,best_d,best_v=e,d,v
    return best_entropy,best_d,best_v

print(try_split(X,y))
best_entropy = try_split(X,y)[0]
best_d = try_split(X,y)[1]
best_v = try_split(X,y)[2]
x_l,x_r,y_l,y_r = split(X,y,best_d,best_v)
print(entropy(y_l))
print(entropy(y_r))

#基尼系数方式构建决策树
#设置决策树的分类器的相关超参数
dt2 = DecisionTreeClassifier(max_depth=2,criterion="gini")
dt2.fit(X,y)
plot_decision_boundary(dt2, axis=[0.5,8,0,3])
plt.scatter(X[y==0,0],X[y==0,1],color="r")
plt.scatter(X[y==1,0],X[y==1,1],color="g")
plt.scatter(X[y==2,0],X[y==2,1],color="b")
plt.show()

def split(x,y,d,value):
    index_a = (x[:,d]<=value)
    index_b = (x[:,d]>value)
    return x[index_a],x[index_b],y[index_a],y[index_b]

#gini指数
def gini(y):
    Counter1 = Counter(y)
    res = 1.0
    for num in Counter1.values():
        p = num/len(y)
        res -= p**2
    return res

#划分
def try_spit1(x,y):
    best_gini = float("inf")
    best_d,best_v = -1,-1
    for d in range(x.shape[1]):
        sorted_index = np.argsort(x[:,d])
        for i in range(1,len(x)):
            if x[sorted_index[i-1],d] != x[sorted_index[i],d]:
                v = (x[sorted_index[i-1],d] + x[sorted_index[i],d])/2
                x_l,x_r,y_l,y_r = split(x,y,d,v)
                g = gini(y_l)+gini(y_r)
                if g <best_gini:
                    best_gini,best_d,best_v=g,d,v
    return [best_gini,best_d,best_v]
best_gini,best_d,best_v=try_spit1(X,y)
print(best_gini,best_d,best_v)

#对决策树进行剪枝，降低过拟合
X,y = datasets.make_moons(noise=0.25,random_state=666)
print(X.shape)
print(y.shape)
plt.figure()
plt.scatter(X[y==0,0],X[y==0,1],color="r")
plt.scatter(X[y==1,0],X[y==1,1],color="g")
plt.show()
dt2 = DecisionTreeClassifier(max_depth=2,min_samples_split=10,min_samples_leaf=6,max_leaf_nodes=4)

#决策树的主要超参数
dt2.fit(X,y)
plot_decision_boundary(dt2,axis=[-2,3,-1,1.5])
plt.scatter(X[y==0,0],X[y==0,1],color="r")
plt.scatter(X[y==1,0],X[y==1,1],color="g")
plt.show()

#使用决策树解决回归问题
d = datasets.load_boston()
X = d.data
y = d.target
print(X.shape)
print(y.shape)
X_train,X_test,y_train,y_test = train_test_split(X,y,random_state=666)
dr = DecisionTreeRegressor()
dr.fit(X_train,y_train)
print(dr.score(X_test,y_test))
print(dr.score(X_train,y_train))
#可以用学习曲线反应是否过拟合
def plot_learning_curve(algo,X_train,X_test,y_train,y_test):
    train_score = []
    test_score = []
    for i in range(1,len(X_train)):
        algo.fit(X_train[:i],y_train[:i])
        y_train_pre = algo.predict(X_train[:i])
        y_test_pre = algo.predict(X_test)
        train_score.append(mean_squared_error(y_train[:i],y_train_pre))
        test_score.append(mean_squared_error(y_test,y_test_pre))
    plt.figure()
    plt.plot([i for i in range(1,len(X_train))],np.sqrt(train_score),"g",label="train_error")
    plt.plot([i for i in range(1,len(X_train))],np.sqrt(test_score),"r",label="test_error")
    plt.legend()
    plt.show()

#欠拟合
plot_learning_curve(DecisionTreeRegressor(max_depth=1),X_train,X_test,y_train,y_test)
#较好拟合
plot_learning_curve(DecisionTreeRegressor(max_depth=5),X_train,X_test,y_train,y_test)
#过拟合
plot_learning_curve(DecisionTreeRegressor(max_depth=15),X_train,X_test,y_train,y_test)
