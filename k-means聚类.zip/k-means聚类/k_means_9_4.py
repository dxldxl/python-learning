# -*- coding: utf-8 -*-
"""
Created on Sat Aug  7 15:06:23 2021

@author: cui
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import random
import time

data=[
      [0.697, 0.460, 1],
        [0.774, 0.376, 1],
        [0.634, 0.264, 1],
        [0.608, 0.318, 1],
        [0.556, 0.215, 1],
        [0.430, 0.237, 1],
        [0.481, 0.149, 1],
        [0.437, 0.211, 1],
        [0.666, 0.091, 0],
        [0.243, 0.267, 0],
        [0.245, 0.057, 0],
        [0.343, 0.099, 0],
        [0.639, 0.161, 0],
        [0.657, 0.198, 0],
        [0.360, 0.370, 0],
        [0.593, 0.042, 0],
        [0.719, 0.103, 0],
        [0.359, 0.188, 0],
        [0.339, 0.241, 0],
        [0.282, 0.257, 0],
        [0.748, 0.232, 0],
        [0.714, 0.346, 1],
        [0.483, 0.312, 1],
        [0.478, 0.437, 1],
        [0.525, 0.369, 1],
        [0.751, 0.489, 1],
        [0.532, 0.472, 1],
        [0.473, 0.376, 1],
        [0.725, 0.445, 1],
        [0.446, 0.459, 1]
      ]
column=['density','sugar_rate','label']
dataSet=pd.DataFrame(data,columns=column)

class K_means(object):
    def __init__(self,k,data,loop_times,error):
        self.k=k
        self.data=data
        self.loop_times=loop_times
        self.error=error
        
    def distance(self,p1,p2):
        #print(np.linalg.norm(np.array(p1)-np.array(p2)))
        return np.linalg.norm(np.array(p1)-np.array(p2))
    
    def fit(self):
        time1 = time.perf_counter()
        #随机选取k个初始样本
        mean_vectors=random.sample(self.data, self.k)
        #print(mean_vectors)
        inital_main_vectors=mean_vectors
        for vec in mean_vectors:
            #画出初始聚类中心，以红色正方形表示
            plt.scatter(vec[0], vec[1], s=100, color='red', marker='s')
            
        times=0
        #聚类中心
        clusters=list(map((lambda x:[x]),mean_vectors))
        #print(clusters)
        while times <self.loop_times:
            #标记簇均值向量是否改变
            change_flag=1
            for sample in self.data:
                dist=[]
                for vec in mean_vectors:
                    #计算该样本到每个聚类中心的距离
                    dist.append(self.distance(vec,sample))
                #找到离该样本最近的聚类中心，并将它放入该簇
                clusters[dist.index(min(dist))].append(sample)
                
            new_mean_vectors=[]
            for c,v in zip(clusters,mean_vectors):
                #print(c)
                #print(v)
                #print(zip(clusters,mean_vectors))
                cluster_num=len(c)
                #print(cluster_num)
                cluster_array=np.array(c)
                # 计算出新的聚类簇均值向量
                new_mean_vector=sum(cluster_array)/cluster_num
                mean_vector=np.array(v)
                #将(new_mean_vector - mean_vector)除以mean_vector的结果
                if all(np.true_divide((new_mean_vector-mean_vector),mean_vector)<np.array([self.error,self.error])):
                    #均值向量未改变
                    new_mean_vectors.append(mean_vector)
                    change_flag=0
                else:
                    #均值向量发生改变
                    new_mean_vectors.append(new_mean_vector.tolist())
                    
            if change_flag==1:
                mean_vectors=new_mean_vectors
            else:
                break
            times+=1
        time2=time.perf_counter()
        print('本次选取的{}个初始向量为{}'.format(self.k, inital_main_vectors))
        print('共进行{}轮'.format(times))
        print('共耗时{:.2f}s'.format(time2-time1))
        for cluster in clusters:
            x=list(map(lambda arr:arr[0], cluster))
            y=list(map(lambda arr:arr[1], cluster))
            plt.scatter(x, y, marker='o',label=clusters.index(cluster)+1)
            
        plt.xlabel('密度')
        plt.ylabel('含糖量')
        plt.rcParams['font.sans-serif']=['SimHei']
        plt.legend(loc='upper left')
        
        plt.show()

for i in [2]:
    k_means=K_means(i,dataSet[['density','sugar_rate']].values.tolist(),100,0.00001)                
    k_means.fit()