# -*- coding: utf-8 -*-
"""
Created on Fri Aug  6 10:32:24 2021

@author: cui
"""

import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import BaggingClassifier,AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier

D=np.array([
    [1, 1, 1, 1, 1, 1, 0.697, 0.460, 1],
    [2, 1, 2, 1, 1, 1, 0.774, 0.376, 1],
    [2, 1, 1, 1, 1, 1, 0.634, 0.264, 1],
    [1, 1, 2, 1, 1, 1, 0.608, 0.318, 1],
    [3, 1, 1, 1, 1, 1, 0.556, 0.215, 1],
    [1, 2, 1, 1, 2, 2, 0.403, 0.237, 1],
    [2, 2, 1, 2, 2, 2, 0.481, 0.149, 1],
    [2, 2, 1, 1, 2, 1, 0.437, 0.211, 1],
    [2, 2, 2, 2, 2, 1, 0.666, 0.091, 0],
    [1, 3, 3, 1, 3, 2, 0.243, 0.267, 0],
    [3, 3, 3, 3, 3, 1, 0.245, 0.057, 0],
    [3, 1, 1, 3, 3, 2, 0.343, 0.099, 0],
    [1, 2, 1, 2, 1, 1, 0.639, 0.161, 0],
    [3, 2, 2, 2, 1, 1, 0.657, 0.198, 0],
    [2, 2, 1, 1, 2, 2, 0.360, 0.370, 0],
    [3, 1, 1, 3, 3, 1, 0.593, 0.042, 0],
    [1, 1, 2, 2, 2, 1, 0.719, 0.103, 0]
    ])

#将特征和标签分离，得到数据集
train_d,label_d=D[:,[-3,-2]],D[:,-1]

# max_depth限定决策树是否为决策树桩，n_estimator表示不同数量的基学习器集成
#下面以Bagging为例，AdaBoost同
clf1=BaggingClassifier(DecisionTreeClassifier(max_depth=1),n_estimators=3)
clf2=BaggingClassifier(DecisionTreeClassifier(max_depth=1),n_estimators=5)
clf3=BaggingClassifier(DecisionTreeClassifier(max_depth=1),n_estimators=11)

#分别进行学习
for clf in [clf1,clf2,clf3]:
    clf.fit(train_d,label_d)
 
    #找到密度和含糖量中的最大最小值，并且-1和+1处理
x_min,x_max=train_d[:,0].min()-1,train_d[:,0].max()+1
#print(x_min,x_max)
y_min,y_max=train_d[:,1].min()-1,train_d[:,1].max()+1
#print(y_min,y_max)

#生成网格点坐标矩阵
xset,yset=np.meshgrid(np.arange(x_min,x_max,0.02),np.arange(y_min,y_max,0.02))
#print(xset,yset)
clf_set,label_set=[clf1,clf2,clf3],[]
#print(clf_set,label_set)

#进行预测，预测完成后添加到标签集中
for clf in clf_set:
    #np.c_[xset.ravel(),yset.ravel()]让生成的坐标点转行成列
    out_label=clf.predict(np.c_[xset.ravel(),yset.ravel()])
    #print(np.c_[xset.ravel(),yset.ravel()])
   # print(out_label)
    out_label=out_label.reshape(xset.shape)
   # print(xset.shape)
    #print(out_label)
    label_set.append(out_label)
    
#生成图像
#figsize设置长，宽；nrows设置高度上面的画面，ncols设置横向的子图个数
fig,axes=plt.subplots(nrows=1, ncols=3,figsize=(12,4))
(ax0,ax1,ax2)=axes.flatten()
#print((ax0,ax1,ax2))
for k,ax in enumerate((ax0,ax1,ax2)):
    #contourf绘制登高线
    ax.contourf(xset,yset,label_set[k],cmap=plt.cm.Set3)
    for i,n,c in zip([0,1],['bad','good'],['black','red']):
        #print(zip([0,1],['bad','good'],['black','red']))
       #根据索引取值
        idx=np.where(label_d==i)
       # print(idx)
        ax.scatter(train_d[idx,0],train_d[idx,1],c=c,label=n)
       # print(train_d[idx,0],train_d[idx,1])
    ax.set_xlim(0,1)
    #显示文本标签的位置
    ax.legend(loc='upper left')
    ax.set_ylabel('suger')
    ax.set_xlabel('density')
    ax.set_title('decision boundary for %s' % (k+1))
plt.show()

