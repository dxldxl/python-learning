# -*- coding: utf-8 -*-
"""
Created on Sat Jul 24 22:35:18 2021

@author: cui
"""
#对率回归
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

#定义了两个数组,表示西瓜数据集中的密度和含糖量
density=np.array([0.697,0.774,0.634,0.608,0.556,0.430,0.481,0.437,0.666,0.243,0.245,0.343,0.639,0.657,0.360,0.593,0.719]).reshape(-1,1)
sugar_rate=np.array([0.460,0.376,0.264,0.318,0.215,0.237,0.149,0.211,0.091,0.267,0.057,0.099,0.161,0.198,0.370,0.042,0.103]).reshape(-1,1)

#将数据水平堆叠，两两配对
xtrain=np.hstack((density,sugar_rate)) 
#shape读取矩阵的行数,ones返回density.shape[0]行1列的全1数组，默认float
xtrain=np.hstack((np.ones([density.shape[0],1]),xtrain))
#print(xtrain)

#返回一个多行1列的数组，使用1和0来表示区分好瓜和坏瓜的标签
ytrain=np.array([1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0]).reshape(-1,1)
#print(ytrain)
#划分训练集和测试集，测试集占数据集的0.25
xtrain,xtest,ytrain,ytest=train_test_split(xtrain,ytrain,test_size=0.25,random_state=33)

def sigmoid(z):
    return 1/(1+np.exp(-z))
#print(sigmoid(density))

#梯度下降，每一次下降的学习率是0.1
#theta是之后调用，随机的生成的一个参数矩阵，iteration控制逻辑回归的梯度下降的次数，此处为100次
def logit_regression(theta,x,y,iteration=100,learning_rate=0.1,lbd=0.01):
    #执行梯度下降100次
    for i in range(iteration):
        #y.shape[0]是整个训练集的数据个数，随机生成的theta矩阵和训练集的x矩阵相乘，得到log中的z,
        #sigmoid(np.dot(x,theta))-y是求假设值和训练集中真实值之间的差值，x.transpose()表示训练集x矩阵的转置
        #x.transpose()表示x矩阵，下标为0的默认为1
        #lbd是惩罚数，lbd*theta是惩罚项，也就是正则项，此问题中不用用到惩罚项
        #下面的算式是更新theta，找到代价最下的theta
        theta=theta-learning_rate/y.shape[0]*(np.dot(x.transpose(),(sigmoid(np.dot(x,theta))-y))+lbd*theta)
        #print(theta)
        
        #计算代价函数
        #y.transpose()表示y的转置，sigmoid(np.dot(x,theta)求假设函数，log求对数
        #lbd/(2*y.shape[0])*np.dot(theta.transpose(),theta)表示正则项
        cost=-1/y.shape[0]*(np.dot(y.transpose(),np.log(sigmoid(np.dot(x,theta))))+np.dot((1-y).transpose(),np.log(1-sigmoid(np.dot(x,theta)))))+lbd/(2*y.shape[0])*np.dot(theta.transpose(),theta)
        print('---------Iteration %d,cost is %f-------------'%(i,cost))
    return theta

def predict(theta,x):
    #用zeros生成与测试集xtrain同样列大小的1行的全为0的矩阵
    pre=np.zeros([x.shape[0],1])
    #print(pre)
    #index表示pre矩阵的下标，valu用于控制遍历的测试集的矩阵下标，pre矩阵用于预测
    #传入的theta是通过梯度下降得到的theta矩阵
    #enumerate是遍历
    for idx,valu in enumerate(np.dot(x,theta)):
        if sigmoid(valu)>=0.5:
            pre[idx]=1
        else:
            pre[idx]=0
    return pre
                
#随机生成一个参数矩阵
theta_init=np.random.rand(3,1)
theta=logit_regression(theta_init,xtrain,ytrain,learning_rate=1)
pre=predict(theta,xtest)
print('predictions are',pre)
print('ground truth is',ytest)
print('theta is ',theta)
print('the accuracy is',np.mean(pre==ytest))
#ytest目标值，测试集的标签，pre预测的结果，target_names表示预测的报表标签，需要和标签顺序一致
print(classification_report(ytest,pre,target_names=['Bad','Good']))
#报表中有precision、recall、 f1-score ，support。其中support表示在测试集中的标签分类。
#accuracy是准确率， macro avg 宏平均是所有类的F1值的算术平均(设 β= 1)