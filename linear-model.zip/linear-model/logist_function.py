# -*- coding: utf-8 -*-
"""
Created on Sun Jul 25 04:24:17 2021

@author: cui
"""

import numpy as np

def sigmoid(z):
    return 1/(1+np.exp(-z))

def logistic_regession(theta,x,y,iteration=100,learning_rate=0.1,lbd=0.001):
    for i in range(iteration):
        theta=theta -learning_rate/x.shape[0]*(np.dot(x.transpose(),sigmoid(np.dot(x,theta))-y)+lbd*theta)
        cost=-1/x.shape[0]*(np.dot(y.transpose(),np.log(sigmoid(np.dot(x,theta))))+np.dot((1-y).transpose(),np.log(1-sigmoid(np.dot(x,theta))))+lbd/(2*y.shape[0])*np.dot(theta.transpose(),theta))
        print("----------第%d次梯度下降，代价是%f---------"%(i,cost))
    
    return theta

def predict(theta,x):
    pre=np.zeros([x.shape[0],1])
    for idx,valu in enumerate(np.dot(x,theta)):
        if sigmoid(valu)>=0.5:
            pre[idx]=1
        else:
            pre[idx]=0
    return pre