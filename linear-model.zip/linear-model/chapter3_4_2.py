# -*- coding: utf-8 -*-
"""
Created on Sun Jul 25 03:52:23 2021

@author: cui
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import KFold
from sklearn.linear_model import LogisticRegression as lrs

#预处理鸢尾花数据集
iris_data=np.array(pd.read_csv('iris.data'))
#去除"Iris-virginica"，只保留两种花
iris_data=iris_data[iris_data[:,4]!="Iris-virginica"]
#使用mapper做标记，来标记两种鸢尾花
mapper={"Iris-setosa":0,"Iris-versicolor":1}

for i in iris_data:
    i[4]=mapper[i[4]]
    
#预处理红酒数据
wine_data=np.array(pd.read_csv('wine.data'))
wine_data=wine_data[:129]

#定义十折交叉验证的筛选器
kf=KFold(10,True)

# 统计鸢尾花数据集十折交叉验证各模型分数
scores11=[]

for train,test in kf.split(iris_data):
    xtrain,xtest=iris_data[train],iris_data[test]
    lr=lrs()
    lr.fit(xtrain[:,0:3],xtrain[:,4].astype('int'))
    scores11.append(lr.score(xtest[:,0:3],xtest[:,4].astype('int')))
    
print(scores11)
    
#统计红酒十折交叉验证个模型分数
scores21=[]

for train,test in kf.split(wine_data):
    xtrain,xtest=wine_data[train],wine_data[test]
    lr=lrs()
    lr.fit(xtrain[:,1:],xtrain[:,0].astype('int'))
    scores21.append(lr.score(xtest[:,1:],xtest[:,0].astype('int')))
    
print(scores21)
    
#定义鸢尾花数据集留一法筛选器
kf1=KFold(iris_data.shape[0],True)

# 统计鸢尾花数据集留一法各模型分数
scores12 = []

for train,test in kf1.split(iris_data):
    xtrain,xtest=iris_data[train],iris_data[test]
    lr=lrs()
    lr.fit(xtrain[:,0:3],xtrain[:,4].astype('int'))
    scores12.append(lr.score(xtest[:, 0:3], xtest[:, 4].astype('int')))

scores22 = []

# 定义红酒数据集留一法筛选器
kf2 = KFold(wine_data.shape[0], True)

# 统计红酒数据集留一法各模型分数
for train, test in kf2.split(wine_data):
    xtrain,xtest = wine_data[train], wine_data[test]
    lr = lrs()
    lr.fit(xtrain[:, 1:], xtrain[:, 0].astype('int'))
    scores22.append(lr.score(xtest[:, 1:], xtest[:, 0].astype('int')))

# 输出最终结果
print("iris:" + str(1 - np.mean(scores11)), str(1 - np.mean(scores12)),'\n',
      "wine:" + str(1 - np.mean(scores21)), str(1 - np.mean(scores22)))

    



    


